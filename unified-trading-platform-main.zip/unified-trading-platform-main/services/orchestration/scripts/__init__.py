"""Utility scripts for AWET."""
